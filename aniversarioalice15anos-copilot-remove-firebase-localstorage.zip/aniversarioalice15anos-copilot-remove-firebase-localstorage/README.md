# 🌸 Aniversário Alice 15 Anos

Um site interativo e elegante para celebrar os 15 anos de Alice Ribeiro!

## ✨ Funcionalidades

- 🎯 **Hero Section** - Apresentação elegante com tema azul e dourado
- 🛍️ **Lista de Presentes** - Apresenta presentes simbólicos com valores
- 💌 **Mural de Cartões** - Visitantes podem deixar cartões carinhosos
- 📸 **Varal de Memórias** - Compartilhamento de fotos em um varal virtual
- 💸 **Área PIX** - Exibição da chave PIX e QR Code
- 👑 **Painel Admin** - Gerenciamento de presentes, PIX e conteúdo

## 🎨 Design

- **Cores Principais**: Azul profundo (#0b131d) com destaque em dourado (#bf953f)
- **Fontes**: Great Vibes (títulos), Poppins (corpo)
- **Responsivo**: Totalmente adaptado para mobile e desktop

## 🔐 Login Admin

Para acessar o painel administrativo:
- **Usuário**: `alice`
- **Senha**: `2026`

### Permissões Admin
- Alterar chave PIX e QR Code
- Adicionar novos presentes
- Gerenciar todas as seções

## 💾 Armazenamento

Todos os dados são salvos no **LocalStorage** do navegador:
- Cartões deixados
- Fotos do varal
- Lista de presentes
- Configuração do PIX

## 📱 Estrutura de Arquivos

```
aniversarioalice15anos/
├── index.html      # Página principal
├── style.css       # Estilos
├── script.js       # Funcionalidades
└── README.md       # Este arquivo
```

## 🚀 Como Acessar

O site está disponível em:
👉 https://joaobolao98-bot.github.io/aniversarioalice15anos/

## 📅 Data Especial

**04 de Dezembro de 2026** - O grande dia dos 15 anos! 🎉

---

*Feito com ❤️ para Alice Ribeiro*