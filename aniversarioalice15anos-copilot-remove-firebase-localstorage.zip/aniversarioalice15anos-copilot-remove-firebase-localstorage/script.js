const STORAGE_KEYS = {
    cartoes: 'alice15_cartoes',
    fotos: 'alice15_fotos_varal',
    presentes: 'alice15_presentes_customizados',
    pix: 'alice15_config_pix'
};

const CHAVE_PIX_PADRAO = 'chave-pix-exemplo-alice@email.com';

const PRESENTES_PADRAO = [
    { nome: 'Leitor de livro digital', valor: '194,17', img: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=500&q=80' },
    { nome: 'Ingresso para festival de música com as amigas', valor: '624,22', img: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=500&q=80' },
    { nome: 'Notebook para focar nos estudos', valor: '260,09', img: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=500&q=80' },
    { nome: 'Celular novo', valor: '260,09', img: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=500&q=80' },
    { nome: 'Seção de fotos', valor: '208,07', img: 'https://images.unsplash.com/photo-1554048612-b6a482bc67e5?auto=format&fit=crop&w=500&q=80' },
    { nome: 'Bicicleta para passear por aí', valor: '208,07', img: 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&w=500&q=80' },
    { nome: 'Kit de cuidados para o cabelo', valor: '208,07', img: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=500&q=80' },
    { nome: 'Vale presente', valor: '156,06', img: 'https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=500&q=80' },
    { nome: 'Acessórios para completar o look', valor: '156,06', img: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&w=500&q=80' },
    { nome: 'Vale para renovar o guarda roupa', valor: '156,06', img: 'https://images.unsplash.com/photo-1558769132-cb1aea458c5e?auto=format&fit=crop&w=500&q=80' },
    { nome: 'Ida ao parque de diversões', valor: '156,05', img: 'https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=500&q=80' },
    { nome: 'Patrocínio para fazer um lanche', valor: '156,05', img: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=500&q=80' },
    { nome: 'Ingresso para rodeio', valor: '156,05', img: 'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=500&q=80' }
];

function lerStorageArray(chave) {
    try {
        const valor = localStorage.getItem(chave);
        return valor ? JSON.parse(valor) : [];
    } catch (error) {
        console.error(`Erro ao ler ${chave}:`, error);
        return [];
    }
}

function salvarStorage(chave, dados) {
    localStorage.setItem(chave, JSON.stringify(dados));
}

function escapeHtml(texto) {
    return String(texto)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function formatarValor(valor) {
    const numero = typeof valor === 'number' ? valor : parseFloat(String(valor).replace(',', '.'));
    return Number.isFinite(numero) ? numero.toFixed(2).replace('.', ',') : String(valor);
}

function paraBase64(arquivo) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (evento) => resolve(evento.target.result);
        reader.onerror = () => reject(new Error('Erro ao processar imagem.'));
        reader.readAsDataURL(arquivo);
    });
}

function adicionarEmoji(emoji) {
    const textarea = document.getElementById('textoMensagem');
    textarea.value += emoji;
    textarea.focus();
}

function copiarChave() {
    const chavePix = document.getElementById('chavePix');

    if (!chavePix.value || chavePix.value === CHAVE_PIX_PADRAO) {
        alert('Configure a chave PIX primeiro! ⚙️');
        return;
    }

    chavePix.select();
    document.execCommand('copy');

    const msg = document.getElementById('msgCopiado');
    msg.style.display = 'inline-block';

    setTimeout(() => {
        msg.style.display = 'none';
    }, 3000);
}

function fazerLogin() {
    const usuario = document.getElementById('loginUsuario').value.trim();
    const senha = document.getElementById('loginSenha').value.trim();

    if (!usuario || !senha) {
        alert('Por favor, preencha usuário e senha! 👑');
        return;
    }

    if (usuario === 'alice' && senha === '2026') {
        document.getElementById('modalLogin').style.display = 'none';
        document.getElementById('painelAdmin').style.display = 'flex';
        document.getElementById('loginUsuario').value = '';
        document.getElementById('loginSenha').value = '';
    } else {
        alert('Usuário ou senha incorretos! ❌');
        document.getElementById('loginSenha').value = '';
    }
}

async function enviarCartao() {
    const nome = document.getElementById('nomeRemetente').value.trim();
    const mensagem = document.getElementById('textoMensagem').value.trim();

    if (!nome || !mensagem) {
        alert('Por favor, preencha nome e mensagem! 💌');
        return;
    }

    if (nome.length < 2) {
        alert('Nome deve ter pelo menos 2 caracteres! 👤');
        return;
    }

    if (mensagem.length < 5) {
        alert('Mensagem deve ter pelo menos 5 caracteres! ✍️');
        return;
    }

    const cartoes = lerStorageArray(STORAGE_KEYS.cartoes);
    cartoes.unshift({
        id: String(Date.now()),
        nome,
        mensagem,
        data: new Date().toLocaleDateString('pt-BR')
    });

    salvarStorage(STORAGE_KEYS.cartoes, cartoes);

    document.getElementById('nomeRemetente').value = '';
    document.getElementById('textoMensagem').value = '';

    carregarCartoes();
    alert('Cartão enviado com sucesso! 💖');
}

function carregarCartoes() {
    const listaCartoes = document.getElementById('listaCartoes');
    listaCartoes.innerHTML = '';

    const cartoes = lerStorageArray(STORAGE_KEYS.cartoes);

    if (cartoes.length === 0) {
        listaCartoes.innerHTML = '<p style="color: #94a3b8; padding: 20px; text-align: center;">Nenhum cartão enviado ainda. Seja o primeiro! 💌</p>';
        return;
    }

    cartoes.forEach((cartao) => {
        const cardElement = document.createElement('div');
        cardElement.className = 'cartao-item';
        cardElement.innerHTML = `
            <button class="btn-remover-cartao" onclick="removerCartao('${escapeHtml(cartao.id)}')" title="Remover">✕</button>
            <p class="mensagem-card">"${escapeHtml(cartao.mensagem)}"</p>
            <span class="autor-card">— ${escapeHtml(cartao.nome)}</span>
        `;
        listaCartoes.appendChild(cardElement);
    });
}

function removerCartao(id) {
    if (!confirm('Tem certeza que deseja remover este cartão?')) {
        return;
    }

    const cartoes = lerStorageArray(STORAGE_KEYS.cartoes).filter((cartao) => cartao.id !== id);
    salvarStorage(STORAGE_KEYS.cartoes, cartoes);
    carregarCartoes();
    alert('Cartão removido! 💔');
}

async function enviarFotoVaral() {
    const nomeFotografo = document.getElementById('nomeFotografo').value.trim();
    const inputFoto = document.getElementById('inputFotoVaral');

    if (!nomeFotografo) {
        alert('Por favor, digite um nome! 📸');
        return;
    }

    if (nomeFotografo.length < 2) {
        alert('Nome deve ter pelo menos 2 caracteres! 👤');
        return;
    }

    if (!inputFoto || inputFoto.files.length === 0) {
        alert('Por favor, selecione uma foto! 📸');
        return;
    }

    const file = inputFoto.files[0];

    if (file.size > 5 * 1024 * 1024) {
        alert('Arquivo muito grande! Máximo 5MB. 📦');
        return;
    }

    if (!file.type.startsWith('image/')) {
        alert('Por favor, selecione uma imagem válida! 🖼️');
        return;
    }

    const fotoBase64 = await paraBase64(file);
    const fotos = lerStorageArray(STORAGE_KEYS.fotos);

    fotos.unshift({
        id: String(Date.now()),
        legenda: nomeFotografo,
        url: fotoBase64
    });

    salvarStorage(STORAGE_KEYS.fotos, fotos);

    document.getElementById('nomeFotografo').value = '';
    document.getElementById('inputFotoVaral').value = '';

    carregarFotosVaral();
    alert('Foto pendurada no varal com sucesso! 🌸');
}

function carregarFotosVaral() {
    const gridVaral = document.getElementById('gridVaral');
    gridVaral.innerHTML = '';

    const fotos = lerStorageArray(STORAGE_KEYS.fotos);

    if (fotos.length === 0) {
        gridVaral.innerHTML = '<p style="color: #94a3b8; padding: 40px; text-align: center; grid-column: 1/-1;">Nenhuma foto no varal ainda. Envie a sua! 📸</p>';
        return;
    }

    fotos.forEach((foto) => {
        const polaroid = document.createElement('div');
        polaroid.className = 'polaroid-item';

        const idEscapado = escapeHtml(foto.id);
        const urlEscapada = escapeHtml(foto.url);
        const legendaEscapada = escapeHtml(foto.legenda);

        polaroid.innerHTML = `
            <button class="btn-remover-foto" onclick="removerFotoVaral('${idEscapado}')" title="Remover">✕</button>
            <img src="${urlEscapada}" alt="${legendaEscapada}" class="polaroid-img" onclick="ampliarFoto('${urlEscapada}', '${legendaEscapada}')">
            <p class="polaroid-legenda">${legendaEscapada}</p>
        `;

        gridVaral.appendChild(polaroid);
    });
}

function removerFotoVaral(id) {
    if (!confirm('Tem certeza que deseja remover esta foto?')) {
        return;
    }

    const fotos = lerStorageArray(STORAGE_KEYS.fotos).filter((foto) => foto.id !== id);
    salvarStorage(STORAGE_KEYS.fotos, fotos);
    carregarFotosVaral();
    alert('Foto removida! 🗑️');
}

function ampliarFoto(url, legenda) {
    const modal = document.createElement('div');
    modal.className = 'modal-foto-ampliada';
    modal.style.display = 'flex';
    modal.style.position = 'fixed';
    modal.style.top = '0';
    modal.style.left = '0';
    modal.style.width = '100%';
    modal.style.height = '100%';
    modal.style.backgroundColor = 'rgba(0, 0, 0, 0.9)';
    modal.style.justifyContent = 'center';
    modal.style.alignItems = 'center';
    modal.style.zIndex = '2000';

    const container = document.createElement('div');
    container.className = 'container-foto-ampliada';
    container.style.position = 'relative';
    container.style.textAlign = 'center';

    const fechar = document.createElement('span');
    fechar.className = 'fechar-foto';
    fechar.textContent = '✕';
    fechar.style.position = 'absolute';
    fechar.style.top = '10px';
    fechar.style.right = '20px';
    fechar.style.fontSize = '40px';
    fechar.style.color = 'white';
    fechar.style.cursor = 'pointer';
    fechar.onclick = () => modal.remove();

    const imagem = document.createElement('img');
    imagem.src = url;
    imagem.alt = legenda || '';
    imagem.className = 'imagem-ampliada';
    imagem.style.maxWidth = '90%';
    imagem.style.maxHeight = '80%';
    imagem.style.borderRadius = '10px';

    const legendaElemento = document.createElement('p');
    legendaElemento.className = 'legenda-ampliada';
    legendaElemento.style.color = '#fff';
    legendaElemento.style.marginTop = '20px';
    legendaElemento.style.fontSize = '18px';
    legendaElemento.textContent = legenda || '';

    container.appendChild(fechar);
    container.appendChild(imagem);
    container.appendChild(legendaElemento);
    modal.appendChild(container);

    modal.onclick = (evento) => {
        if (evento.target === modal) {
            modal.remove();
        }
    };

    document.body.appendChild(modal);
}

async function salvarConfigPix() {
    const novaChave = document.getElementById('adminNovaChavePix').value.trim();
    const novoQrCode = document.getElementById('adminNovoQrCode').files[0];

    if (!novaChave && !novoQrCode) {
        alert('Por favor, preencha a chave PIX ou selecione um QR Code! 💸');
        return;
    }

    if (novaChave && novaChave.length < 5) {
        alert('Chave PIX inválida! ❌');
        return;
    }

    if (novoQrCode && novoQrCode.size > 2 * 1024 * 1024) {
        alert('Arquivo muito grande! Máximo 2MB. 📦');
        return;
    }

    if (novoQrCode && !novoQrCode.type.startsWith('image/')) {
        alert('Por favor, selecione uma imagem válida para o QR Code! 🖼️');
        return;
    }

    const configAtual = (() => {
        try {
            return JSON.parse(localStorage.getItem(STORAGE_KEYS.pix)) || {};
        } catch (error) {
            console.error('Erro ao ler config PIX:', error);
            return {};
        }
    })();

    const novaConfig = { ...configAtual };

    if (novaChave) {
        novaConfig.chave = novaChave;
    }

    if (novoQrCode) {
        novaConfig.qrCodeUrl = await paraBase64(novoQrCode);
    }

    localStorage.setItem(STORAGE_KEYS.pix, JSON.stringify(novaConfig));

    document.getElementById('adminNovaChavePix').value = '';
    document.getElementById('adminNovoQrCode').value = '';

    carregarConfigPix();
    alert('Configurações PIX atualizadas com sucesso! 💸');
}

function carregarConfigPix() {
    try {
        const config = JSON.parse(localStorage.getItem(STORAGE_KEYS.pix)) || {};

        const campoPix = document.getElementById('chavePix');
        campoPix.value = config.chave || CHAVE_PIX_PADRAO;

        const imgQr = document.getElementById('imagemQrCodeExibicao');
        if (config.qrCodeUrl) {
            imgQr.src = config.qrCodeUrl;
            imgQr.style.display = 'block';
        } else {
            imgQr.src = 'seu-qr-code.png';
            imgQr.style.display = 'block';
        }
    } catch (error) {
        console.error('Erro ao carregar PIX:', error);
    }
}

async function adicionarNovoPresente() {
    const nome = document.getElementById('novoNomePresente').value.trim();
    const valor = document.getElementById('novoValorPresente').value.trim();
    const inputFoto = document.getElementById('novaFotoPresente');

    if (!nome || !valor) {
        alert('Por favor, preencha nome e valor! 🎁');
        return;
    }

    if (nome.length < 3) {
        alert('Nome do presente deve ter pelo menos 3 caracteres! 📝');
        return;
    }

    const valorNormalizado = valor.replace(',', '.');
    if (Number.isNaN(Number.parseFloat(valorNormalizado))) {
        alert('Valor deve ser um número válido! 💰');
        return;
    }

    if (!inputFoto || inputFoto.files.length === 0) {
        alert('Por favor, selecione uma foto! 📸');
        return;
    }

    const file = inputFoto.files[0];

    if (!file.type.startsWith('image/')) {
        alert('Por favor, selecione uma imagem válida! 🖼️');
        return;
    }

    if (file.size > 3 * 1024 * 1024) {
        alert('Arquivo muito grande! Máximo 3MB. 📦');
        return;
    }

    const fotoBase64 = await paraBase64(file);
    const presentes = lerStorageArray(STORAGE_KEYS.presentes);

    presentes.unshift({
        id: String(Date.now()),
        nome,
        valor: Number.parseFloat(valorNormalizado),
        img: fotoBase64
    });

    salvarStorage(STORAGE_KEYS.presentes, presentes);

    document.getElementById('novoNomePresente').value = '';
    document.getElementById('novoValorPresente').value = '';
    document.getElementById('novaFotoPresente').value = '';

    carregarPresentes();
    alert('Presente adicionado com sucesso! 🎁');
}

function carregarPresentes() {
    const presentesCustomizados = lerStorageArray(STORAGE_KEYS.presentes);
    const presentes = presentesCustomizados.length > 0
        ? [...PRESENTES_PADRAO, ...presentesCustomizados]
        : PRESENTES_PADRAO;

    const gridPresentes = document.getElementById('gridPresentes');
    gridPresentes.innerHTML = '';

    presentes.forEach((presente) => {
        const card = document.createElement('div');
        card.className = 'presente-card';

        const nomeEscapado = escapeHtml(presente.nome);
        const valorFormatado = formatarValor(presente.valor);
        const valorEscapado = escapeHtml(valorFormatado);

        card.innerHTML = `
            <img src="${escapeHtml(presente.img)}" alt="${nomeEscapado}" class="img-presente" onerror="this.src='https://via.placeholder.com/300x300?text=Sem+Imagem'">
            <h3>${nomeEscapado}</h3>
            <p class="valor">R$ ${valorEscapado}</p>
            <button class="btn-comprar" onclick="abrirModalPresente('${nomeEscapado}', '${valorEscapado}')">Escolher 🎁</button>
        `;

        gridPresentes.appendChild(card);
    });
}

function abrirModalPresente(titulo, valor) {
    document.getElementById('tituloModalPresente').textContent = titulo;
    document.getElementById('textoModalPresente').textContent = `Valor simbólico: R$ ${valor}`;
    document.getElementById('modalPresente').style.display = 'flex';
}

function fecharModal() {
    document.getElementById('modalPresente').style.display = 'none';
}

function irParaPix() {
    const chavePix = document.getElementById('chavePix').value;

    if (!chavePix || chavePix === CHAVE_PIX_PADRAO) {
        alert('Chave PIX não configurada! Configure no painel administrativo. ⚙️');
        return;
    }

    alert(`Para completar sua compra, utilize:\n\nChave PIX: ${chavePix}\n\nOu escaneie o QR Code! 📱`);
    fecharModal();
}

function abrirLogin() {
    document.getElementById('modalLogin').style.display = 'flex';
}

function fecharLogin() {
    document.getElementById('modalLogin').style.display = 'none';
    document.getElementById('loginUsuario').value = '';
    document.getElementById('loginSenha').value = '';
}

function fecharPainelAdmin() {
    document.getElementById('painelAdmin').style.display = 'none';
}

function fazerLogout() {
    fecharPainelAdmin();
    alert('Você saiu do painel. Volte sempre! 👑');
}

window.onclick = (event) => {
    const modal = document.getElementById('modalPresente');
    if (event.target === modal) {
        modal.style.display = 'none';
    }

    const modalLogin = document.getElementById('modalLogin');
    if (event.target === modalLogin) {
        modalLogin.style.display = 'none';
    }

    const painelAdmin = document.getElementById('painelAdmin');
    if (event.target === painelAdmin) {
        painelAdmin.style.display = 'none';
    }
};

document.addEventListener('DOMContentLoaded', () => {
    carregarPresentes();
    carregarCartoes();
    carregarFotosVaral();
    carregarConfigPix();
});
