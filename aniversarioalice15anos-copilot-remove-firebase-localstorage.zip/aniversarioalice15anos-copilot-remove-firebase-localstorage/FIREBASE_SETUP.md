# 🚀 SETUP FIREBASE EM 2 MINUTOS (GRÁTIS)

## ⚡ Passo 1: Criar Projeto Firebase (1 MINUTO)

1. Acesse: https://console.firebase.google.com/
2. Clique em **"Adicionar Projeto"**
3. Nome: `aniversarioalice15anos`
4. **Desmarque "Google Analytics"** (economiza créditos!)
5. Clique **"Criar Projeto"**
6. Aguarde 1 minuto...

## ⚡ Passo 2: Copiar Credenciais (30 SEGUNDOS)

1. Clique em **"Web"** (ícone `</>`
2. Copie o código `firebaseConfig`
3. Abra o arquivo `firebase-config.js` do seu repositório
4. Cole suas credenciais no lugar de `SUA_API_KEY_AQUI`

## ⚡ Passo 3: Ativar Firestore Database (30 SEGUNDOS)

1. No menu, vá em **"Build"** → **"Firestore Database"**
2. Clique **"Create Database"**
3. Selecione **"Start in test mode"** (liberado)
4. Localização: **us-central1** (padrão)
5. Clique **"Create"**

## ⚡ Passo 4: Ativar Firebase Storage (15 SEGUNDOS)

1. Menu: **"Build"** → **"Storage"**
2. Clique **"Get Started"**
3. Modo: **"Start in test mode"**
4. Clique **"Create"**

## ✅ PRONTO! Seu site agora sincroniza na nuvem!

### 💰 Por que NÃO vai gastar créditos?

- Firebase Spark Plan (GRÁTIS):
  - ✅ 1 GB Firestore Storage
  - ✅ 50k leituras/dia
  - ✅ 20k escritas/dia
  - ✅ Sem cartão de crédito obrigatório!

### 📝 Seu site vai:
- ✅ Sincronizar cartões em todos os dispositivos
- ✅ Salvar fotos na nuvem
- ✅ Nunca perder dados
- ✅ Funcionar offline (com cache)

### ⚠️ IMPORTANTE

Se quiser adicionar o arquivo `firebase-config.js` no seu index.html, adicione ANTES do `<script src="script.js"></script>`:

```html
<!-- Firebase -->
<script src="https://www.gstatic.com/firebasejs/9.22.2/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.22.2/firebase-firestore.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.22.2/firebase-storage.js"></script>
<script src="firebase-config.js"></script>
```

E depois atualize as funções no `script.js` para usar as funções Firebase!

---

**Criado em:** 12/09/2026 ✨
